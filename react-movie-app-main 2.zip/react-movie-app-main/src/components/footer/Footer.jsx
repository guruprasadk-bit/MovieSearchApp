import React from "react";
import {
  FaInstagram,
  FaTwitter,
  FaLinkedin,
  FaGithub,
  FaGitlab,
} from "react-icons/fa";

import ContentWrapper from "../contentWrapper/ContentWrapper";
import "./style.scss";

const Footer = () => {
  return (
    <footer className="footer">
      <ContentWrapper>
      {/*  <ul className="menuItems">
          <li className="menuItem">Terms Of Use</li>
          <li className="menuItem">Privacy-Policy</li>
          <a style={{ color: "white",textDecoration:"none" }} href="https://vaibhav-more-portfolio-site.netlify.app/"><li  className="menuItem">About</li></a>
          <a style={{ color: "white", textDecoration: "none" }} href="https://medium.com/@vaibhavmore24051997"><li className="menuItem">Blog</li></a>
          <li className="menuItem">FAQ</li>
        </ul>*/}
        <div className="infoText">
          React Movie App.
        </div>

      </ContentWrapper>
    </footer>
  );
};

export default Footer;
